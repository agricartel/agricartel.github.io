# Powerline config

Copy this folder to `~/.config`. 
